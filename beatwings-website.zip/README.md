# BEATWINGS Website

Statische Website – kein Build, keine Abhängigkeiten. Alle Dateien liegen flach im Stammverzeichnis.

## Inhalt

| Datei | Inhalt |
|---|---|
| `beatwings.html` | Startseite: News-Lauftext, Hero, Reisen, Festival Moments, News, Gewinnspiel, Warteliste |
| `gewinnspiel.html` | Adventskalender-Gewinnspiele inkl. vollständiger Teilnahmebedingungen |
| `bw-*.jpg` | Alle Bilder, von den beiden Seiten relativ eingebunden |

## Auf GitHub Pages veröffentlichen

1. Alle Dateien dieses Ordners ins **Stammverzeichnis** des Repositories pushen (nicht in einen Unterordner – sonst finden die Seiten ihre Bilder nicht).
2. Im Repository auf **Settings → Pages** gehen.
3. Unter *Build and deployment* bei *Source* **Deploy from a branch** wählen, Branch `main`, Ordner `/ (root)`, speichern.
4. Nach ein bis zwei Minuten ist die Seite erreichbar unter `https://<benutzername>.github.io/<repository>/beatwings.html`.

**Wichtig:** Die Startseite heißt bewusst `beatwings.html` und nicht `index.html`. Die Adresse muss deshalb immer mit `/beatwings.html` enden – die reine Stammadresse zeigt nichts an, solange dort keine eigene `index.html` liegt.

Eigene Domain: unter *Settings → Pages → Custom domain* eintragen; die Seite liegt dann unter `https://eure-domain.de/beatwings.html`.

## Technisches

- Hell- und Dunkelmodus folgen der Systemeinstellung des Besuchers.
- Für Handys optimiert: Viewport gesetzt, eigene wischbare Navigationszeile, große Tippflächen, kein seitliches Scrollen.
- Schriften kommen von Google Fonts (Bricolage Grotesque, Archivo) und brauchen eine Internetverbindung.
- Animationen schalten sich ab, wenn im Betriebssystem „Bewegung reduzieren" aktiv ist.
- Die Buchungs-Buttons verlinken auf `booking.beatwings.com`.

## Noch offen

- Die Links zu Impressum, AGB, Datenschutz und FAQ im Footer sind noch Platzhalter (`#`).
- Die Clips sind aktuell Standbilder mit Play-Button – echte Videos müssen noch eingebunden werden.
- Bildrechte prüfen: Die Songkran-Aufnahmen stammen laut Website-Galerie von Ewald Geerdink und Michiel Ton.
