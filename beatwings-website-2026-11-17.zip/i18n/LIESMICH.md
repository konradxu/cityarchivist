# Sprachen der BEATWINGS-Website – so funktioniert die Tabelle

Stand 17.11.2026 · KI Team (Codi, William)

Alle Texte der Website stehen in **einer** Datei: `i18n/sprachen.csv`.
Eine Zeile pro Text, eine Spalte pro Sprache. Es gibt keine einzelnen Sprachdateien mehr.

## Aufbau

| Spalte | Bedeutung |
|---|---|
| `id` | Name des Textes. **Nicht ändern** – die Website findet den Text über diesen Namen. |
| `_wo` | Auf welchen Seiten der Text steht (nur zur Orientierung). |
| `de` | Deutscher Text. Wird auch auf der deutschen Seite verwendet – eine Änderung hier ändert die Website. |
| `en` … `ar` | Übersetzungen. Leere Zelle = der deutsche Text erscheint. |

Zwei besondere Zeilen oben:
- `_name` – so heißt die Sprache im Sprachmenü (z. B. „Français“).
- `_dir` – Schreibrichtung: `ltr` (links nach rechts) oder `rtl` (Arabisch).

Zeilen, deren `id` mit `t.` beginnt, sind Texte, die per Skript entstehen (Menü, Reels).
Platzhalter in geschweiften Klammern wie `{pf}` oder `{name}` müssen stehen bleiben.

## Text ändern
1. `sprachen.csv` öffnen (Numbers, Google Sheets, LibreOffice oder Excel).
2. Zelle ändern.
3. Speichern als **CSV UTF-8** (in Excel: „CSV UTF-8 (durch Trennzeichen getrennt)“). Andere CSV-Varianten zerstören Umlaute und Sonderzeichen.
4. Datei auf IONOS in den Ordner `i18n/` hochladen und die alte ersetzen. Nach spätestens einer Stunde sehen alle Besucher die Änderung (sofort mit Neuladen).

## Neue Sprache hinzufügen
1. Neue Spalte rechts anfügen, Kopf = Sprachcode (z. B. `sv` für Schwedisch).
2. In der Zeile `_name` den Namen eintragen (z. B. `Svenska`), in `_dir` `ltr`.
3. Texte übersetzen. Die Sprache erscheint automatisch im Sprachmenü aller Seiten.

## Wichtig
- Texte mit `<a …>`, `<b>` usw. enthalten Links bzw. Formatierung. Den Teil in spitzen Klammern unverändert lassen, nur den Text dazwischen übersetzen.
- Rechtstexte (Impressum, Datenschutz, AGB) bleiben deutsch. In anderen Sprachen erscheint davor ein Hinweis (Zeile `legal.note`).
- Die Sprache wird über die Website selbst geladen. Wer eine Seite nur lokal per Doppelklick öffnet, sieht deshalb immer Deutsch – auf IONOS funktioniert der Wechsel.
- Wechsel per Link: `beatwings.html?lang=en`
