# Reels auf der Startseite – so pflegst du sie

Stand 17.11.2026 · KI Team (Codi)

Die Datei `inhalte/reels.csv` legt fest, welche Reels im Bereich „Reels“ laufen.

```
plattform;link
tiktok;https://www.tiktok.com/@beatwingsadventure/video/1234567890123456789
instagram;https://www.instagram.com/reel/ABCdefGHIjk/
```

- Eine Zeile pro Reel, **neueste zuerst**. Gezeigt werden die ersten vier.
- `plattform` ist `tiktok` oder `instagram`.
- Den Link kopierst du in der App über „Teilen → Link kopieren“.
- Speichern als CSV UTF-8, hochladen in den Ordner `inhalte/`.

**Ohne Einträge** zeigt die Seite das TikTok-Profil @beatwingsadventure mit den jeweils neuesten Videos – das aktualisiert sich von selbst.

**Automatisch abspielen:** TikTok-Reels starten stumm und in Schleife. Instagram erlaubt kein automatisches Abspielen; dort startet das Video per Klick.

**Datenschutz:** Videos laden erst, wenn Besucher im Hinweisfenster „Videos zulassen“ wählen. Die Wahl lässt sich jederzeit über „Video-Einstellungen“ im Footer ändern.
